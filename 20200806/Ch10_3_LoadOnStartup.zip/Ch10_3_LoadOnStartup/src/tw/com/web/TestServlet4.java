package tw.com.web;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//loadOnStartup ��b�e���B��ɤ@�P�إߪ���
@WebServlet(urlPatterns = {"/TestServlet4"},loadOnStartup = 3)
public class TestServlet4 extends HttpServlet {
	@Override
	public void init() throws ServletException {
		System.out.println("init Start TestServlet4.....");
		try {
			TimeUnit.SECONDS.sleep(5);
		}catch(Exception ex) {
			
		}
		System.out.println("init End TestServlet4.....");
		
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().println("TestServlet4");
	}
}
