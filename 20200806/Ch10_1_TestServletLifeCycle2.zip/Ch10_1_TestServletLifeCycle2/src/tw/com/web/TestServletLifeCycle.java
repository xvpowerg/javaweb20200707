package tw.com.web;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TestServletLifeCycle")
public class TestServletLifeCycle extends HttpServlet {
		
//		@Override
//		public void init(ServletConfig sc)  {
//			System.out.println("init(ServletConfig)!!!");			
//		}
	
		@Override
		public void init() throws ServletException {
			// TODO Auto-generated method stub
				System.out.println("init()!!!");
		}
		
	@Override
	protected void doGet(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().append("TestServletLifeCycle!!");
	}
	
//	@Override
//		public void service(ServletRequest req, ServletResponse res)
//						throws ServletException, IOException {
//			System.out.println("service(ServletRequest ServletResponse)");
//			//super.service(req, res);
//		}
	
	@Override
		public void destroy() {
		System.out.println("destroy!");
		}
}
