package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OrderDetailServlet
 */
@WebServlet("/OrderDetailServlet")
public class OrderDetailServlet extends HttpServlet {   
	
	private String toTableString(HttpServletRequest request) {
	
		String tableHtml = "<table class=\"table table-hover\">%s%s</table>";
		String thHtml = "<tr>" + 
				"			<th>�~�W</th>" + 
				"			<th>���B</th>" + 
				"			<th>�ƶq</th>" + 
				"		</tr>";
		//%s ���ܦr��  %d���ܾ��
		String trHtml = "<tr>" + 
				"			<td>%s</td>" + 
				"			<td>%s</td>" + 
				"			<td>%s</td>" + 
				"		</tr>";
		
		    String[] itemNames=request.getParameterValues("itemName");
		    String[] priceArray=request.getParameterValues("price");
			String[] countArray=request.getParameterValues("count");
			
			StringBuilder sb = new StringBuilder();
			for (int i =0 ;i < itemNames.length;i++) {
				String newTrHtml = String.format(trHtml, itemNames[i],
													     priceArray[i],
													     countArray[i]);
				sb.append(newTrHtml);				
			}
			final String finalTable = String.format(tableHtml, thHtml,sb.toString());
		return finalTable;
	}
	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
  	    PrintWriter out = response.getWriter();
  	 out.print("<HTML>");
  	 out.print("<HEAD>");  	
  	 out.print("<meta charset=\"UTF-8\">");
  	 out.print("<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css\" integrity=\"sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk\" crossorigin=\"anonymous\">");
  	 out.print("</HEAD>");
     out.print("<BODY>");
     out.print("<DIV class=\"container\">");
	 out.print(toTableString(request));     
     out.print("</DIV>");    
  	 out.print("</BODY>");  	
     out.print("</HTML>");
  	  
    
  	  
//name�L���ƪ��ɭ�		
//		String itemName =  request.getParameter("itemName");
//		String count = request.getParameter("count");
//		String price =  request.getParameter("price");
//		System.out.println(itemName+","+count+","+price);
	

		
	}



}
