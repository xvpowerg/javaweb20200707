package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoinVerificationServlet")
public class LoinVerificationServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			//��ܵn�J���\ 
		//�n�J���ѭ�]
	resp.setContentType("text/html;charset=UTF-8");
	PrintWriter out = resp.getWriter();
	out.println("LoinVerificationServlet!!!");	
	//���o�ݭn����LoginServlet �]�w���ƭ�
	List<String>  errorMsgList = 
			(List) req.getAttribute("errorMsgList");
	
		if (errorMsgList.isEmpty()) {
			out.println("<h1>�n�J���\</h1>");
		}else {
			
			for (String msg : errorMsgList) {
				String errorMsg = String.format("<p style=\"color:red\";"
									+ "font-size:30px>%s</p>", msg);
				out.println(errorMsg);
			}
			
		}
		
	}
 
}
