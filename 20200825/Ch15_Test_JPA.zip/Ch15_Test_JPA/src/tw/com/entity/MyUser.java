package tw.com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class MyUser {
   @Id  //�]���D��
   @GeneratedValue //@GeneratedValue ���ͬy����
  private int id;
  private String account;
  private String password;
  // @Column ���wtable �W��
  @Column(name="user_name",length=20)
  private String name;
}
