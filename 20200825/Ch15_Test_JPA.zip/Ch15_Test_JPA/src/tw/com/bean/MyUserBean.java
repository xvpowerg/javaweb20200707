package tw.com.bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import tw.com.entity.MyUser;

/**
 * Session Bean implementation class MyUserBean
 */
@Stateless
public class MyUserBean implements MyUserBeanLocal {
	@Inject
	private EntityManager em;
    public MyUserBean() {
       
    }

	@Override
	public void createUser(MyUser myUser) {
		// TODO Auto-generated method stub
		em.persist(myUser);
	}

	@Override
	public MyUser login(String account, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
