package tw.com.bean;

import javax.ejb.Local;

import tw.com.entity.MyUser;

@Local
public interface MyUserBeanLocal {
    void createUser(MyUser myUser);
    MyUser login(String account,String password);
}
