package tw.com.factory;

import tw.com.dao.MyUserDao;
import tw.com.dao.MyUserDaoImpMySQL;

public class DaoFactory {
	private enum DbType{
	MySQL,
	MsSQL		
	}
	
	private static DbType dbType;
	public static void setDbType(String type) {
		dbType = DbType.valueOf(type);
	}
   public static MyUserDao createMyUserDao() {
	   switch(dbType) {
	   case MySQL:
		   return new MyUserDaoImpMySQL();
	   case  MsSQL:
		   return new MyUserDaoImpMySQL();
	   }
	   return null;
   }
}
