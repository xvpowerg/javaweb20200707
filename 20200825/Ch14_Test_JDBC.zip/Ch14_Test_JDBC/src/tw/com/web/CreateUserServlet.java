package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.MyUser;
import tw.com.dao.MyUserDao;
import tw.com.dao.MyUserDaoImpMySQL;
import tw.com.model.MyUserModel;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;



@WebServlet("/CreateUserServlet")
public class CreateUserServlet  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	MyUserModel um = new MyUserModel();
//		MyUser myUser = new MyUser();
//		myUser.setAccount("qwer2");
//		myUser.setPassword("12345");
//		myUser.setUserName("Ken");
//		um.createUser(myUser);
	  PrintWriter out =   resp.getWriter();
	  if (um.checkAccountAndPassword("qwer1",
			  "12345")) {
		   out.println("Pass!");
	  }else {
		  out.println("Fail");
	  }
		
	}
}
