package tw.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import tw.com.bean.MyUser;
import tw.com.db.DbManager;

public class MyUserDaoImpMySQL implements MyUserDao{
	
	private static DbManager  dm;
	
	static {
		try {
			  dm = DbManager.getDBManager();
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException:"+e);
			
		}
	}
	@Override
	public boolean insert(MyUser myuser) {
		// TODO Auto-generated method stub
		try(Connection con = dm.getConnection();
			Statement stm =	con.createStatement()){
			//password account �O�o�n�[�K �i�ϥ�AES �Ψ�L�[�K��q
			String sql = "INSERT INTO my_user(account,password,user_name) VALUES ('%s','%s','%s')";
			sql = String.format(sql, myuser.getAccount(),myuser.getPassword(),myuser.getUserName());
			System.out.println("sql:"+sql);
			stm.executeUpdate(sql);
			
		} catch (SQLException e) {
			System.out.println(e);	
			return false;
		}
		return true;
	}

	@Override
	public ResultSet queryMyUserAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResultSet queryMyUserById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateMyUser(MyUser myuser) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteMyuser(MyUser myuser) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ResultSet queryByAccount(String account) {
		// TODO Auto-generated method stub
		String sql= "SELECT * FROM my_user WHERE account = ?";
		try{
			Connection con = dm.getConnection();
			PreparedStatement stm =	con.prepareStatement(sql);
			stm.setString(1, account);
			return stm.executeQuery();
			
		}catch(SQLException ex){
			System.out.println(ex);
		}
		return null;
	}

}
