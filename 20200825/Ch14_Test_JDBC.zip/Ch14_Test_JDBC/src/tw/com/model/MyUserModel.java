package tw.com.model;

import java.sql.SQLException;

import tw.com.bean.MyUser;
import tw.com.dao.MyUserDao;
import tw.com.dao.MyUserDaoImpMySQL;

public class MyUserModel {
	private MyUserDao dao = new MyUserDaoImpMySQL();
	public boolean createUser(MyUser myUser) {
		
		return dao.insert(myUser);
	}
	
	public boolean checkAccountAndPassword(String account,
			String password) {
		boolean isPass = false;
		try {
			MyUser myUser =   dao.queryMyUserByAccount(account);		
		   return 	myUser!= null && 
				   myUser.getPassword().equals(password);									
		} catch (SQLException e) {
			System.out.println("SQLException:"+e);
		}		
		return isPass;
	}
}
