package tw.com.listener;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import java.util.Random;
@WebListener
public class MyRequestListener implements ServletRequestListener {

	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		// TODO Auto-generated method stub		
		System.out.println("requestDestroyed!!");
	}

	@Override
	public void requestInitialized(ServletRequestEvent sre) {
		ServletRequest sr =  sre.getServletRequest();
		Random ran = new Random();
		sr.setAttribute("test", ran.nextInt(90000));
		System.out.println("requestInitialized!!");
	}
	
	
}
