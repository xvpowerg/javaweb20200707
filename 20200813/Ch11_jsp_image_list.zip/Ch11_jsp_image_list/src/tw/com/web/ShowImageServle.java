package tw.com.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.model.IoTools;

@WebServlet("/ShowImageServle")
public class ShowImageServle  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//C:\Users\xvpow\JavaWebClass\Ch11_jsp_image_list\WebContent\images
		String imageFilePath = getServletContext().getInitParameter("imageFilePath");
		System.out.println(imageFilePath);
		List<String> imagePahtList =  IoTools.getImages(imageFilePath);
		HttpSession ses = req.getSession();
		ses.setAttribute("imagePahtList", imagePahtList);
		System.out.println(imagePahtList);
		resp.sendRedirect("show_image.jsp");
		
	}
}
