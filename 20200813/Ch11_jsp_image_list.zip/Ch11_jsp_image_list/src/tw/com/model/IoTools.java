package tw.com.model;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
public class IoTools {
	public static List<String> getImages(String imageDirPath)throws IOException {
		   Path imagePath =  Paths.get(imageDirPath);
		   Stream<Path> st = Files.list(imagePath);
		  List<String> list =  st.map(path->path.getFileName().toString()).
		   	   collect(Collectors.toList());
		return list;
	}
	
	public static String toTargetPath(String imageDirPath,
			String fileName) {
		
		return imageDirPath+File.separator+fileName;
	}
	
	public static void receiveFile(InputStream src,String target) 
			throws IOException {
		
		try(OutputStream out = new FileOutputStream(target);){
				int index = -1;
				byte[] buffer = new byte[1024];
				while( (index = src.read(buffer)) != -1) {
					out.write(buffer, 0, index);	
				}
		}
			
		
	}
}
