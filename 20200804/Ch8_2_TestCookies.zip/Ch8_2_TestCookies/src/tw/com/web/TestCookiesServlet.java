package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TestCookiesServlet")
public class TestCookiesServlet extends HttpServlet {

	
	private void initCookie(HttpServletResponse resp) {
		//Cookie �Ĥ@�ӰѼƬOname
		//�Ĥ@�ӰѼƬOvalue
		Cookie cookie = new Cookie("count","1");
		//setMaxAge ���O��
		//�p�G�]��0 �ߨ���� Cookie
		//cookie.setMaxAge(0);
		//�p�G�]���t�� �s���������ɥߨ���� Cookie			
		//cookie.setMaxAge(-1);
		//60*60*24 ���ܤ@��
		cookie.setMaxAge(60*60*24);
		//�b�s�����s�W�@��Cookie
		resp.addCookie(cookie);
		//cookies = req.getCookies();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Cookie �w�]�s����������ƴN����
		Cookie[] cookies =   req.getCookies();
		PrintWriter out =   resp.getWriter();
		String countStr = "1";
		boolean findCount = false;

		if (cookies == null) {
			initCookie(resp);
		}else {
			for (Cookie c : cookies) {				
				if(c.getName().equals("count")) {
					findCount = true;
					String count =   c.getValue();
					int countInt = Integer.parseInt(count);
					countInt++;
					countStr =  String.valueOf(countInt);
					c.setValue(countStr);
					c.setMaxAge(60*60*24);
					resp.addCookie(c);
					break;
				}				
			}	
		}
		
		if (!findCount) {
			initCookie(resp);
		}
		out.println(countStr);
		
	}
}
