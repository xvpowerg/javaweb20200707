package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;


@WebServlet("/TestLoignCookieServlet")
public class TestLoignCookieServlet  extends  HttpServlet{
	
	
	private String getNewCookieValue(String oldCookieValue,boolean first) {
		LocalDateTime dateTime =  LocalDateTime.now();
		String dateTimeStr =  dateTime.toString();
		String resultStr = "";
			if (first) {
				resultStr = "1#"+dateTimeStr;
			}else {
				String[] cookieSplit= oldCookieValue.split("#");
				String countStr =  cookieSplit[0];
				 int count = Integer.parseInt(countStr);
				 count++;
				 resultStr = count+"#"+dateTimeStr;	 
			}
		return resultStr;
	}
	
	private String getNewCookieValue(String oldCookieValue) {
		
		return getNewCookieValue(oldCookieValue,false);
	}
	private String getNewCookieValue() {
		return getNewCookieValue(null,true);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		String cookieInfo = "";
		int hour1 = 60*60;
			//�p�G���b���Ĥ@���n�J �h��ܱz�Ĥ@���n�J
   		    //�p�G���b���D�Ĥ@�n�J �h��ܤW�n�J�ɶ��P�n�J����
//		LocalDateTime localDateTime = LocalDateTime.now();
//		System.out.print(localDateTime.toString());
		
		String account = req.getParameter("account");
		boolean findUser = false;
		//�@��Cookie ������@�ӱb��
		Cookie[] cookies =   req.getCookies();
	     if(cookies != null) {
	    	 for (Cookie c : cookies) {
	    	    if(c.getName().equals(account)) {
	    	    	findUser = true;
	    	    	c.setMaxAge(hour1);	    	    	
	    	    	String newValue = getNewCookieValue(c.getValue());
	    	    	cookieInfo = newValue;
	    	    	c.setValue(newValue);
	    	    	resp.addCookie(c);	    	   
	    	    	break;
	    	    }
	    		 
	    	 }
	     }
		
	     //�p�G�S���۹������b�� �άO cookies��null
	     if (!findUser) {	    	 
	    	 out.print("<H1>�w��"+account+"�Ĥ@���n�J</H1>");
	    	 String value = getNewCookieValue();
	    	 Cookie cookie = new Cookie(account,value);	    	 
	    	 cookie.setMaxAge(hour1);
	    	 resp.addCookie(cookie);
	     }else {
	    	  String[] cookieSplit= cookieInfo.split("#");
	    	 String info =
	    			 String.format("<H1>%s �n�J�F:%s�� �W���n�J�ɶ�:%s</H1>", 
	    					 account,cookieSplit[0],cookieSplit[1]);
	    	 out.print(info);    	 
	     }
		
		
	}
}
