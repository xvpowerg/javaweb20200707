package tw.com.web;

public class Test1 {
	String value1;
	public void doGet() {
		
	}
}
