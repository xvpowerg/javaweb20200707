package tw.com.model;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.io.IOException;
public class IoTools {
	public static List<String> getImages(String imageDirPath)throws IOException {
		   Path imagePath =  Paths.get(imageDirPath);
		   Stream<Path> st = Files.list(imagePath);
		  List<String> list =  st.map(path->path.getFileName().toString()).
		   	   collect(Collectors.toList());
		   		  
		return list;
	}
}
