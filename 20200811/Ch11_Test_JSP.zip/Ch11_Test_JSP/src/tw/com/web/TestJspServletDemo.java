package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class TestJspServletDemo extends HttpServlet {
	
	private void _jsp(HttpServletRequest req,HttpServletResponse resp) throws IOException {
		
		
		
		PrintWriter out =   resp.getWriter();
		String[] products = {"A","B","C"};
		for (int i =0; i<products.length;i++){
				
			out.print(products[i]);
			
		}
	}
	
   @Override
protected void doGet(HttpServletRequest req,
		HttpServletResponse resp) throws ServletException, IOException {
	   _jsp(req,resp);
   }
   @Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	   _jsp(req,resp);
	   
	}
   
}
//	     String products = req.getParameter("products");
//	     resp.setContentType("text/html;charset=UTF-8");
//	     
//	     String htmpTmple ="<!DOCTYPE html>\r\n" + 
//	     		"<html>\r\n" + 
//	     		"<head>\r\n" + 
//	     		"<style>\r\n" + 
//	     		"	.productColor{\r\n" + 
//	     		"		color:red;		\r\n" + 
//	     		"	}\r\n" + 
//	     		"</style>\r\n" + 
//	     		"<meta charset=\"UTF-8\">\r\n" + 
//	     		"<title>Insert title here</title>\r\n" + 
//	     		"</head>\r\n" + 
//	     		"<body>"; 
//	     PrintWriter out =   resp.getWriter();		
//	     out.print(htmpTmple);
//	     if (products != null) {
//	    	 
//		     String[] prodArray = products.split(",");
//		     
//		   
//		     String ckeckBoxHtml = 
//		    		 "<input type=\"checkbox\" name=\"product\" value=\"%d\"/>"
//		    		 + "<p class='%s'>%s</p>";
//		     for (int i =0;i<prodArray.length;i++) {
//		    	 String classStyle= "";
//		    	 if (i==0) {
//		    		 classStyle= "productColor";
//		    	 }
//		    	 out.print(String.format(ckeckBoxHtml, i,classStyle,prodArray[i]));
//		     }
//	    	 
//	    	 
//	     }
//	     out.print("</body>\r\n" + 
//	     		"</html>");

//}
//}
