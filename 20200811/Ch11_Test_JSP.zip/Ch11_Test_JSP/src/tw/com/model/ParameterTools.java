package tw.com.model;

public class ParameterTools {
    public static String[] parseToArray(String products) {
    		if (products == null) return new String[0];
    	  String[] data =  products.split(",");    	  
		   return data;
	}
}
