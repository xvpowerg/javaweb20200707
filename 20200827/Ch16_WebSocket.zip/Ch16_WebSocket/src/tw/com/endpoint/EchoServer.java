package tw.com.endpoint;

import javax.websocket.OnMessage;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/echo")
public class EchoServer {
	//�����T�� �P�^�ǰT��
	@OnMessage
	public String message(String message) {
		
		 message = message.toUpperCase();
		
		return "Ok!!"+message;
	}
}
