package tw.com.cdi;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class EMProvider {
	//@PersistenceContext ���� EntityManager �浹�e���hnew
	@PersistenceContext
	@Produces
	private EntityManager em;
}
