package tw.com.ws;

import javax.ejb.EJB;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.bean.MyUserBeanLocal;
import tw.com.entity.MyUser;

@Path("user")
@Produces(MediaType.APPLICATION_JSON)
public class UserService {
	@EJB
	private MyUserBeanLocal myUserBean;
	
	@GET
	public String testResful() {
		
		return "{\"status\": true}";
	}
	
//	@POST
//	public String createUesr(@QueryParam("name") String name,
//			@QueryParam("account") String account,
//			@QueryParam("password") String password) {
//		MyUser myuser = new MyUser();
//		myuser.setAccount(account);
//		myuser.setName(name);
//		myuser.setPassword(password);
//		myUserBean.createUser(myuser);
//		return "{\"status\": true}";
//	}
	
	
	@POST
	public String createUesr(
			@DefaultValue("empty")
			@FormParam("name") String name,
			@FormParam("account") String account,
			@FormParam("password") String password) {
		MyUser myuser = new MyUser();
		myuser.setAccount(account);
		myuser.setName(name);
		myuser.setPassword(password);
		myUserBean.createUser(myuser);
		return "{\"status\": true}";
	}
	
	@POST
	@Path("login")
	public String login(@FormParam("account") String account,
			@FormParam("password") String password) {
	MyUser myUser = myUserBean.login(account, password);
		 if (myUser == null) {
			 return "{\"status\": false}";
		 }
		 //�⪫����JSON
		 ObjectMapper om= new ObjectMapper();
		 String json = "{}";
		 try {
			json = om.writeValueAsString(myUser);
		} catch (JsonProcessingException e) {
			System.out.println("JsonProcessingException:"+e);
		}
		return json;
	}
}
