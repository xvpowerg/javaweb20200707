package tw.com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

//:account �O�@�ӰѼ�
@Entity
@NamedQueries({	
	@NamedQuery(name="findMyUserByAccount",
			query="SELECT myUserObj FROM MyUser myUserObj WHERE myUserObj.account = :account")
})
public class MyUser {
	@Id // �]���D��
	@GeneratedValue // @GeneratedValue ���ͬy����
	private int id;
	private String account;
	private String password;
	// @Column ���wtable �W��
	@Column(name = "user_name", length = 20)
	private String name;

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

}
