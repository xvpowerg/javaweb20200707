package tw.com.web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {

}
