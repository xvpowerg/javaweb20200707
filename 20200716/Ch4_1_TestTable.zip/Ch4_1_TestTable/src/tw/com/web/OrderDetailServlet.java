package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OrderDetailServlet
 */
@WebServlet("/OrderDetailServlet")
public class OrderDetailServlet extends HttpServlet {       
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").
		append(request.getContextPath());
//name�L���ƪ��ɭ�		
//		String itemName =  request.getParameter("itemName");
//		String count = request.getParameter("count");
//		String price =  request.getParameter("price");
//		System.out.println(itemName+","+count+","+price);
	
		String[] itemNames=request.getParameterValues("itemName");
		String[] countArray=request.getParameterValues("count");
		String[] priceArray=request.getParameterValues("price");
		
		for (int i =0 ;i < itemNames.length;i++) {
			System.out.println(itemNames[i]+":"+countArray[i]+
								":"+priceArray[i]);
		}
		
	}



}
