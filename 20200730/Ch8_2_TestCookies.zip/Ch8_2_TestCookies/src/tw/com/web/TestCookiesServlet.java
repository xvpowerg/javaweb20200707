package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TestCookiesServlet")
public class TestCookiesServlet extends HttpServlet {

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Cookie �w�]�s����������ƴN����
		Cookie[] cookies =   req.getCookies();
		PrintWriter out =   resp.getWriter();
		String countStr = "1";
		boolean cookiesFind = false;
		if (cookies == null) {
			//Cookie() �Ĥ@�ӰѼƬ�name
			//��2�ӰѼƬ�value
			Cookie cookie = new Cookie("count","1");
			resp.addCookie(cookie);
			cookies = req.getCookies();
		}else {
			for (Cookie c : cookies) {
				if (c.getName().equals("count")) {
					String count =   c.getValue();
					int countInt = Integer.parseInt(count);
					countInt++;
					c.setValue(countInt+"");
					resp.addCookie(c);
					countStr = countInt+"";
					cookiesFind = true;
					break;
				}
			}
			if (!cookiesFind) {
				Cookie cookie = new Cookie("count","1");
				resp.addCookie(cookie);
			}
		}
		out.println(countStr);
		
	}
}
