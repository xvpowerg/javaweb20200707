package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private String account= "qwer";
	private String password = "12345";

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
	    PrintWriter out =   resp.getWriter();
		String account = req.getParameter("account");
		String password = req.getParameter("password");
		if (account.equals(this.account) && 
				password.equals(this.password)) {
			out.println("<p>�n�J���\</p>");
			HttpSession session = req.getSession();
			User user = new User("Ken","A0011");	
			session.setAttribute("user", user);
			//sendRedirect �@�ߦbGet
			resp.sendRedirect("UserInfoServlet");
			//getRequestDispatcher �p�G�_�I�O�bdoPost �ؼ��I�]�|�I�sdoPost
			//req.getRequestDispatcher("/UserInfoServlet").forward(arg0, arg1);
		}else {
			out.println("<p>�n�J����<p/>");
		}
	}
}
