package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.app.Application;

@WebServlet("/CheckBoxServlet")
public class CheckBoxServlet extends HttpServlet {
	//����getParameter���g�k
	String getParameter(String name) {
		HttpServletRequest req = null;
		Map<String,String[]> map =	 req.getParameterMap();
	      String[] hobbies2 = map.get(name);
		return hobbies2[0];
	}
	
	//����getParameterValues���g�k
	String[] getParameterValues(String name) {
		HttpServletRequest req = null;
		Map<String,String[]> map =	 req.getParameterMap();
	      String[] hobbies2 = map.get(name);
		return hobbies2;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");		
		PrintWriter out =   resp.getWriter();		
		//�ѼƦW�٤����Ʈ�
		 //String hobby =  req.getParameter("hobby");
		 //System.out.println(hobby);
		//�ѼƦW�٭��Ʈ�
		 String[] hobbies = req.getParameterValues("hobby");
      	
      			
		 if (hobbies != null) {
			 for (String v : hobbies) {
				 out.println(
						 Application.HOBBBYS[ Integer.parseInt(v) ] +"<BR/>");	 
			 }
		 }
	
		 
		 
	}
		
}
