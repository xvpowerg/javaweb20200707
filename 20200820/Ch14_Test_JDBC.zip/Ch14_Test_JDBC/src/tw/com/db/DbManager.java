package tw.com.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbManager {
     
	private static DbManager dbm;
	private String url;
	private String account;
	private String password;
	
    public static void newDbManager(String url,String account,String password ) {
    	dbm = new DbManager();
    	dbm.url = url;
    	dbm.account = account;
    	dbm.password = password;
    }
    
    public static DbManager getDBManager()throws IllegalAccessException {
    	if (dbm == null) {
    		throw new IllegalAccessException("DbManager Is  Null");
    	}
    	return dbm;
    }
	
	public  Connection getConnection() throws SQLException {
		Connection conn  = DriverManager.getConnection(url,account,password);
		return conn;
	}
	
}
