package tw.com.model;

import tw.com.bean.MyUser;
import tw.com.dao.MyUserDao;
import tw.com.dao.MyUserDaoImpMySQL;

public class MyUserModel {
	
	public boolean createUser(MyUser myUser) {
		MyUserDao dao = new MyUserDaoImpMySQL();
		return dao.insert(myUser);
	}
}
