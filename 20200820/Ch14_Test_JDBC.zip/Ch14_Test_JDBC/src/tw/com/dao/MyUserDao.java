package tw.com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import tw.com.bean.MyUser;

public interface MyUserDao {
	boolean insert(MyUser myuser);
	ResultSet queryMyUserAll();
	ResultSet queryMyUserById(int id);
	boolean updateMyUser(MyUser myuser);
	boolean deleteMyuser(MyUser myuser);
	
	
	static List<MyUser> resultSetToList(ResultSet res) throws SQLException{			
		List<MyUser> userList = new ArrayList<>();
		while(res.next()) {
			int id = res.getInt(1);
			String account = res.getString(2);
			String password =  res.getString(3);
			String userName =  res.getString(4);
			MyUser myUser = new MyUser();
			myUser.setId(id);
			myUser.setAccount(account);
			myUser.setPassword(password);			
			myUser.setUserName(userName);
			userList.add(myUser);
		}				
		return userList;
	}
	
	default List<MyUser> queryMyUserAllToList() throws SQLException{		
		ResultSet res = queryMyUserAll();		
		return resultSetToList(res);
	}
	
	default List<MyUser> queryMyUserByIdToList(int id) throws SQLException{
		ResultSet res = queryMyUserById(id);		
		return resultSetToList(res);
	}
	
}
