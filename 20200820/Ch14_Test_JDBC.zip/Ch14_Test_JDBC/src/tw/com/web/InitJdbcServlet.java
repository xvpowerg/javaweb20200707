package tw.com.web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import tw.com.db.DbManager;


@WebServlet(loadOnStartup = 1,urlPatterns = {"/InitJdbcServlet"})
public class InitJdbcServlet extends HttpServlet {
	
	@Override
	public void init() throws ServletException {
		String url = getServletContext().getInitParameter("url");
		String account = getServletContext().getInitParameter("account");
		String password = getServletContext().getInitParameter("password");
		
		DbManager.newDbManager(url, account, password);
	}

}
