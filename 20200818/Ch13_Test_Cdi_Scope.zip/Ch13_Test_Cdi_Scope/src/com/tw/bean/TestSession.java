package com.tw.bean;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;

@SessionScoped
public class TestSession implements Serializable{
	private String name = "TestSession empty";
	@Override
	public String toString() {
		return "TestSession [name=" + name + "]";
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
