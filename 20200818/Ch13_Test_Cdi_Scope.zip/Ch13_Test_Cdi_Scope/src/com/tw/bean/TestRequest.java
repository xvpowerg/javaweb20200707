package com.tw.bean;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class TestRequest {
	 private String name = "TestRequest empty";

	@Override
	public String toString() {
		return "TestRequest [name=" + name + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	 
	 
}
