package com.tw.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.bean.TestRequest;
import com.tw.bean.TestSession;
@WebServlet("/Page2Servlet")
public class Page2Servlet extends HttpServlet {
	@Inject
	TestRequest tr;
	@Inject
	TestSession ts;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = resp.getWriter();
		out.print("Page2Servlet:");
		out.print(tr);
		out.print("<br/>");
		out.print("Page2Servlet Session:");
		out.print(ts);
	}
}
