package tw.com.web;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.Book;
import tw.com.bean.Fly;
import tw.com.bean.Student;
import tw.com.bean.TestBeans;

import java.util.List;
@WebServlet("/TestCdiServlet")
public class TestCdiServlet extends HttpServlet {
//Contexts and Dependency Injection //CDI
	//@Inject ���i��b��k��
	//����new Book
	

	@Inject
	Book book;
	
	@Inject
	Student st;
	
	@Named("bird")
	@Inject
	Fly fly;
	
	@Named("airplan")
	@Inject
	Fly aFly;
	
	@Inject
	List<String> myFruitList;
	
	@Inject
	List<Integer> myPriceList;
	

	@Named("TestBeans")
	@Inject
	TestBeans tb;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println(book);
		System.out.println("St Book:"+st.getBook());
		fly.flaying();
		aFly.flaying();
		System.out.println("myFruitList:"+myFruitList);
		System.out.println("myPriceList:"+myPriceList);
		System.out.println("TestBeans:"+tb);
	}
	
	
}
