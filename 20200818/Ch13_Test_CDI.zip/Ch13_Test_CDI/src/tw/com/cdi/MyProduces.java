package tw.com.cdi;

import java.util.List;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import tw.com.bean.Book;
import tw.com.bean.TestBeans;

import java.util.ArrayList;
public class MyProduces {
@Produces
	public List<String> getFruit(){
		List<String> list = new ArrayList();
		list.add("Apple");
		list.add("Banana");
		list.add("Cherry");
		return list;
	}

@Produces
public List<Integer> getPrice(){
	List<Integer> list = new ArrayList();
	list.add(10);
	list.add(20);
	list.add(60);
	return list;
}

@Named("TestBeans")
@Produces
public TestBeans getTest(){
	TestBeans myTb = new TestBeans();
	myTb.name = "MyTestBeans";			
	return myTb;
}



}
