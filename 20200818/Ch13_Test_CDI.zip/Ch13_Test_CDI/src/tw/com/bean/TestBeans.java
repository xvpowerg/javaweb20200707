package tw.com.bean;

public class TestBeans {
	public String name;

	
	@Override
	public String toString() {
		return "TestBeans [name=" + name + "]";
	}
	
	
	
}
