package tw.com.bean;

import javax.enterprise.inject.Default;
import javax.inject.Named;

@Named("airplan")
public class AirPlan implements Fly {
	@Override
	public void flaying() {
		System.out.println("AirPlan flaying!!");
	}

}
