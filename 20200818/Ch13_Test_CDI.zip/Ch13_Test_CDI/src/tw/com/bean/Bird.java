package tw.com.bean;

import javax.inject.Named;

@Named("bird")
public class Bird implements Fly {
		public  void flaying() {
			System.out.println("Bird flaying!");			
		}
}
