package tw.com.bean;

public interface Fly {
    void flaying();
}
