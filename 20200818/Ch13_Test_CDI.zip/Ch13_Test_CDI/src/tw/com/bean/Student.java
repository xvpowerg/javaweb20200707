package tw.com.bean;

import javax.inject.Inject;
import javax.inject.Named;

public class Student {
	
  private Book book;

 
  public Book getBook() {	  
	  return book;
  }

  public void setBook(Book book) {
	  book.setName("android");
	  book.setPrice(100);
	  book.setIsbn("AB0001");
	  this.book = book;
  }
  
}
